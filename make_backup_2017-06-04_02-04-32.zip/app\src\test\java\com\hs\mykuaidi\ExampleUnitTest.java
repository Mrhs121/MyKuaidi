package com.hs.mykuaidi;

import org.junit.Test;

import org.junit.Assert;

 /**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        Assert.assertEquals(4, 2 + 2);
        Assert.assertEquals(4, 2 + 2);

    }
}