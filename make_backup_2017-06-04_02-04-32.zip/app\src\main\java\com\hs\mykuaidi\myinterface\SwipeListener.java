package com.hs.mykuaidi.myinterface;

import android.view.View;

/**
 * Created by 黄晟 on 2017/1/17.
 */

public interface SwipeListener extends View.OnClickListener {
    public void onSwipeListener();
}
