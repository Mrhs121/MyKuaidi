package com.hs.mykuaidi.myinterface;

/**
 * Created by 黄晟 on 2016/10/5.
 */

public interface FragmentListener {
    public void onFragmentClickListener(int item);
}
